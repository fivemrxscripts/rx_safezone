Config = {}

Config.Locations = {
	{
		Coords = vector3(314.6751, -589.9202, 43.2841),
		Type = 'sphere',
		Radius = 50.0
	},
	{
		Coords = vector3(234.8725, -793.0062, 30.5522),
		Type = 'sphere',
		Radius = 40.0
	},
	{
		Coords = vector3(1690.7778, 2596.5005, 45.5587),
		Type = 'sphere',
		Radius = 200.0
	},
	{
		Coords = vector3(323.8232, -209.6485, 54.0863),
		Type = 'sphere',
		Radius = 50.0
	}
}