author 'rx_scripts'
description 'Safezony'
game 'gta5'
fx_version 'cerulean'
lua54 'yes'

client_script 'client.lua'
client_script 'config.lua'

shared_scripts {
    '@ox_lib/init.lua'
}