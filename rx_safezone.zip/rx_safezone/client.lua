local inside = false

local function Inside(self)
	local playerPed = PlayerPedId()
	SetEntityCanBeDamaged(playerPed, false)
	SetPlayerCanDoDriveBy(playerPed, false)
	DisablePlayerFiring(playerPed, true)
	DisableControlAction(0, 140, true) -- Melee R
	local vehicle = GetVehiclePedIsIn(playerPed, false)
	if vehicle ~= 0 then
		local vehicles = lib.getNearbyVehicles(self.coords, self.radius, false)

		for _,v in ipairs(vehicles) do
			SetEntityNoCollisionEntity(v.vehicle, vehicle, true)
		end

		local peds = lib.getNearbyPeds(self.coords, self.radius)
		for _,v in ipairs(peds) do
			SetEntityNoCollisionEntity(v.ped, vehicle, true)
		end
	end
end

local function OnEnter()
	lib.notify({
		description = 'Vstoupil jsi do safezone.',
		type = 'success'
	})
	inside = true
end

local function OnExit()
	local playerPed = PlayerPedId()
	SetEntityCanBeDamaged(playerPed, true)
	lib.notify({
		description = 'Opustil jsi safezone.',
		type = 'error'
	})
	inside = false
end

CreateThread(function()
	for k,v in ipairs(Config.Locations) do
		lib.zones[v.Type]({
			coords = v.Coords,
			radius = v.Radius,
			size = vector3(v.Radius, v.Radius, 20.0),
			inside = Inside,
			onEnter = OnEnter,
			onExit = OnExit
		})
	end
end)

exports('isInside', function()
	return inside
end)